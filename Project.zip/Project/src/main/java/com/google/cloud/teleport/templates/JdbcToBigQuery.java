package main.java.com.google.cloud.teleport.templates;

import com.google.api.services.bigquery.model.TableRow;
import com.google.cloud.teleport.options.CommonTemplateOptions;
import java.sql.Clob;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAccessor;
import org.apache.beam.sdk.options.Default;
import org.apache.beam.sdk.io.jdbc.JdbcIO;
import org.apache.beam.sdk.io.gcp.bigquery.TableRowJsonCoder;
import com.google.cloud.teleport.io.DynamicJdbcIO;
import com.google.cloud.teleport.templates.common.JdbcConverters;
import com.google.cloud.teleport.util.KMSEncryptedNestedValueProvider;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.PipelineResult;
import org.apache.beam.sdk.options.PipelineOptions;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.options.ValueProvider;
import org.apache.beam.sdk.values.PCollection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.sql.Types;
import org.apache.beam.sdk.options.Validation.Required;
import javax.lang.model.util.ElementKindVisitor9;
import java.util.*;
import java.sql.*;
import java.sql.Date;
import java.sql.Timestamp;

public class JdbcToBigQuery {

    private static final Logger LOG = LoggerFactory.getLogger(JdbcToBigQuery.class);
   // private static final Logger LOG =LoggerFactory.getLogger(JdbcConvertors.class);
  
    private static String finalStatement;
    private static String destTable;
    private static int numberOfcolumns;
    private static ArrayList<String> columnNames=new ArrayList<String>();
    private static ArrayList<String> colTypes=new ArrayList<String>();

    public static void setColumnList(ArrayList<String> listCol,ArrayList<String> columTypes){
        columnNames=listCol;
        colTypes=columTypes;
    }
    
    public static String setFinalStmt(int numOfcols, String table){
        String stmntPrep = "?" + ",?".repeat(numOfcols-1);                
        return "insert into "+table+" values("+stmntPrep+")";
    }

    private static ValueProvider<String> maybeDecrypt(
        ValueProvider<String> unencryptedValue, ValueProvider<String> kmsKey) {
        return new KMSEncryptedNestedValueProvider(unencryptedValue, kmsKey);
    }
  
    /**
     * Main entry point for executing the pipeline. This will run the pipeline asynchronously. If
     * blocking execution is required, use the {@link
     * JdbcToBigQuery#run(JdbcConverters.JdbcToBigQueryOptions)} method to start the pipeline and
     * invoke {@code result.waitUntilFinish()} on the {@link PipelineResult}
     *
     * @param args The command-line arguments to the pipeline.
     */
    public static void main(String[] args) {
  
      // Parse the user options passed from the command-line
      JdbcConverters.JdbcToBigQueryOptions options =
          PipelineOptionsFactory.fromArgs(args)
              .withValidation()
              .as(JdbcConverters.JdbcToBigQueryOptions.class);
  
      run(options);
    }
   
    
    private static PipelineResult run(JdbcConverters.JdbcToBigQueryOptions options) {
        
        Pipeline pipeline = Pipeline.create(options);
        LOG.info("Disabled Algorithms: {}", options.getDisabledAlgorithms());
        
        String destTable=options.getTableName().toString();
        Integer columnCount=options.getColumnCount().get();
        String finalstmt = setFinalStmt(columnCount, destTable);
        
        PCollection<TableRow> poutput =pipeline.apply("Read from JdbcIO",DynamicJdbcIO.<TableRow>read()
            .withDataSourceConfiguration(DynamicJdbcIO.DynamicDataSourceConfiguration.create(options.getDriverClassName(),maybeDecrypt(options.getSourceURL(), options.getKMSEncryptionKey()))
            .withUsername(maybeDecrypt(options.getSourceUsername(), options.getKMSEncryptionKey()))
            .withPassword(maybeDecrypt(options.getSourcePassword(), options.getKMSEncryptionKey()))
            .withDriverJars(options.getDriverJars())
            .withConnectionProperties(options.getConnectionProperties()))
            .withQuery(options.getQuery())
            .withCoder(TableRowJsonCoder.of())
            .withRowMapper(new JdbcIO.RowMapper<TableRow>() {  
                public TableRow mapRow(ResultSet resultSet) throws Exception {

                    SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
                    DateTimeFormatter datetimeFormatter =
                    DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm:ss.SSSSSS");
                    SimpleDateFormat timestampFormatter =
                    new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.SSSSSSXXX");

                    ResultSetMetaData metaData = resultSet.getMetaData();

                    TableRow outputTableRow = new TableRow();
                    ArrayList<String> tempColNames=new ArrayList<String>();
                    ArrayList<String> tmpColTypes=new ArrayList<String>();
                    for(int i=1;i<=metaData.getColumnCount();i++){
                        tempColNames.add(metaData.getColumnName(i));
                        tmpColTypes.add(metaData.getColumnTypeName(i));
                    }
                    setColumnList(tempColNames, tmpColTypes);
                    
                    for (int i = 1; i <= metaData.getColumnCount(); i++) {
                        if (resultSet.getObject(i) == null) {
                        outputTableRow.set(metaData.getColumnName(i), "null");
                        continue;
                    }
                
                    switch (metaData.getColumnTypeName(i).toLowerCase()) {
                        case "date":
                            outputTableRow.set(
                                metaData.getColumnName(i), dateFormatter.format(resultSet.getDate(i)));
                            break;
                        case "datetime":
                            outputTableRow.set(
                                metaData.getColumnName(i),
                                datetimeFormatter.format((TemporalAccessor) resultSet.getObject(i)));
                            break;
                        case "timestamp":
                            outputTableRow.set(
                                metaData.getColumnName(i),resultSet.getTimestamp(i));
                            break;
                        case "clob":
                            Clob clobObject = resultSet.getClob(i);
                            // Clob clobObject = resultSet.getClob(i);
                            if (clobObject.length() > Integer.MAX_VALUE) {
                            LOG.warn(
                                "The Clob value size {} in column {} exceeds 2GB and will be truncated.",
                                clobObject.length(),
                                metaData.getColumnName(i));
                            }
                            outputTableRow.set(
                                metaData.getColumnName(i), clobObject.getSubString(1, (int) clobObject.length()));
                            break;
                        default:
                            outputTableRow.set(metaData.getColumnName(i), resultSet.getObject(i));
                    }
                }
                return outputTableRow;
                }
            })); 


        poutput.apply(JdbcIO.<TableRow>write().
            withDataSourceConfiguration(JdbcIO.DataSourceConfiguration
            .create(options.getDestDriverClass(), options.getDestURL())
            .withUsername(options.getDestUsername())
            .withPassword(options.getDestPassword()))
            .withStatement(finalstmt)
            .withPreparedStatementSetter(new JdbcIO.PreparedStatementSetter<TableRow>() {
                public void setParameters(TableRow element,
                    java.sql.PreparedStatement preparedStatement) throws Exception {
                        
                        for(int i=0;i<columnNames.size();i++){
                            if(element.get(columnNames.get(i)).equals("null"))
                                {
                                    preparedStatement.setNull(1+i , Types.NULL);   
                                }
                            else{
                                if(colTypes.get(i).toLowerCase()=="date"){
                                    java.sql.Date sqlPackageDate = Date.valueOf((String)element.get(columnNames.get(i)));
                                    preparedStatement.setDate(1+i,sqlPackageDate);
                                    //System.out.println(colTypes.get(i)+element.get(columnNames.get(i)));
                                
                                }
                                else if(colTypes.get(i).toLowerCase()=="timestamp"){
                                    java.sql.Timestamp sqlPackageTime =new Timestamp((Long)element.get(columnNames.get(i)));
                                    preparedStatement.setTimestamp(1+i,sqlPackageTime);
                                    //System.out.println(colTypes.get(i)+element.get(columnNames.get(i)));
                                }
                                else{
                                    preparedStatement.setObject(1+i,element.get(columnNames.get(i)));
                                }
                            }
                        }
                    }
                } )
             );
        return pipeline.run();
    }

}
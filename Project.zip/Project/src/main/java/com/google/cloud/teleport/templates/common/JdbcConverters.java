/*
 * Copyright (C) 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package com.google.cloud.teleport.templates.common;

import com.google.api.services.bigquery.model.TableRow;
import com.google.cloud.teleport.options.CommonTemplateOptions;
import java.sql.Clob;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAccessor;
import org.apache.beam.sdk.io.jdbc.JdbcIO;
import org.apache.beam.sdk.options.Description;
import org.apache.beam.sdk.options.ValueProvider;
import org.slf4j.Logger;
import org.apache.beam.sdk.options.Default;
import org.apache.beam.sdk.options.Validation.Required;

import java.time.temporal.TemporalAccessor;
import org.apache.beam.sdk.io.jdbc.JdbcIO;
import org.apache.beam.sdk.options.PipelineOptions;
import org.slf4j.LoggerFactory;

/** Common code for Teleport JdbcToBigQuery. */
public class JdbcConverters {

  private static final Logger LOG = LoggerFactory.getLogger(JdbcConverters.class);

  /** Interface used by the JdbcToBigQuery pipeline to accept user input. */
  public interface JdbcToBigQueryOptions extends CommonTemplateOptions {

    @Description(
        "Comma separate list of driver class/dependency jar file GCS paths "
            + "for example "
            + "gs://<some-bucket>/driver_jar1.jar,gs://<some_bucket>/driver_jar2.jar")
    ValueProvider<String> getDriverJars();

    void setDriverJars(ValueProvider<String> driverJar);

    @Description("The JDBC driver class name. " + "for example: com.mysql.jdbc.Driver")
    ValueProvider<String> getDriverClassName();

    void setDriverClassName(ValueProvider<String> driverClassName);

    @Description("Username for postgres")
    //@Default.String("")
    ValueProvider<String> getPostgresUser();
    void setPostgresUser(ValueProvider<String> username);
    
    @Description("Password for postgres")
   // @Default.String("")
    ValueProvider<String> getPostgresPassword();
    void setPostgresPassword(ValueProvider<String> password);

    @Description(
        "The JDBC connection URL string. " + "for example: jdbc:mysql://some-host:3306/sampledb")
        @Default.String("")
    ValueProvider<String> getConnectionURL();
    void setConnectionURL(ValueProvider<String> connectionURL);

    @Description(
        "JDBC connection property string. " + "for example: unicode=true&characterEncoding=UTF-8")
    ValueProvider<String> getConnectionProperties();

    void setConnectionProperties(ValueProvider<String> connectionProperties);

    @Description("JDBC connection user name. ")
    @Default.String("")
    ValueProvider<String> getUsername();

    void setUsername(ValueProvider<String> username);

    @Description("JDBC connection password. ")
    @Default.String("")
    ValueProvider<String> getPassword();
    void setPassword(ValueProvider<String> password);

    @Description("Source data query string. " + "for example: select * from sampledb.sample_table")
    @Default.String("")
    ValueProvider<String> getQuery();
    void setQuery(ValueProvider<String> query);

    @Description(
        "BigQuery Table spec to write the output to"
            + "for example: some-project-id:somedataset.sometable")
            @Default.String("")
    ValueProvider<String> getOutputTable();
    void setOutputTable(ValueProvider<String> value);

    @Description("Temporary directory for BigQuery loading process")
    ValueProvider<String> getBigQueryLoadingTemporaryDirectory();

    void setBigQueryLoadingTemporaryDirectory(ValueProvider<String> directory);

    @Description(
        "KMS Encryption Key should be in the format"
            + " projects/{gcp_project}/locations/{key_region}/keyRings/{key_ring}/cryptoKeys/{kms_key_name}")
    ValueProvider<String> getKMSEncryptionKey();

    void setKMSEncryptionKey(ValueProvider<String> keyName);

    @Description(
        "The JDBC source connection URL string. " + "for example: jdbc:mysql://some-host:3306/sampledb")
        @Default.String("")
    ValueProvider<String> getSourceURL();

    void setSourceURL(ValueProvider<String> sourceURL);

    @Description("JDBC source className. ")
    ValueProvider<String> getSourceDriverClass();
    void setSourceDriverClass(ValueProvider<String> driverClass);

    @Description("JDBC source connection user name. ")
    @Default.String("")
    ValueProvider<String> getSourceUsername();

    void setSourceUsername(ValueProvider<String> sourceUsername);

    @Description("JDBC source connection password. ")
    @Default.String("")
    ValueProvider<String> getSourcePassword();

    void setSourcePassword(ValueProvider<String> sourcePassword);

    @Description("JDBC source connection password. ")
    @Default.String("")
    ValueProvider<String> getSourceQuery();

    void setSourceQuery(ValueProvider<String> sourceQuery);

    @Description(
        "The JDBC source connection URL string. " + "for example: jdbc:mysql://some-host:3306/sampledb")
        @Default.String("")
    ValueProvider<String> getDestURL();

    void setDestURL(ValueProvider<String> destURL);

    @Description("JDBC source connection user name. ")
    @Default.String("")
    ValueProvider<String> getDestUsername();

    void setDestUsername(ValueProvider<String> destUsername);

    @Description("JDBC source connection password. ")
    @Default.String("")
    ValueProvider<String> getDestPassword();

    void setDestPassword(ValueProvider<String> destPassword);

    @Description("JDBC destination class name. ")
    ValueProvider<String> getDestDriverClass();

    void setDestDriverClass(ValueProvider<String> DestDrverClass);

  /*  @Description("JDBC source connection table. ")
    ValueProvider<String> getTableName();

    void setTableName(ValueProvider<String> tableName);*/

   @Description("JDBC source connection password. ")
   @Default.String("")
    ValueProvider<String> getDestQuery();

    void setDestQuery(ValueProvider<String> destQuery);

    @Description("Tablename ")
    @Default.String("")
    ValueProvider<String> getTableName();

    void setTableName(ValueProvider<String> tableName);

    @Description("Number of columns ")
    ValueProvider<Integer> getColumnCount();

    void setColumnCount(ValueProvider<Integer> count);
   }

  /** Factory method for {@link ResultSetToTableRow}. */
  public static JdbcIO.RowMapper<TableRow> getResultSetToTableRow() {
    return new ResultSetToTableRow();
  }

  /**
   * {@link JdbcIO.RowMapper} implementation to convert Jdbc ResultSet rows to UTF-8 encoded JSONs.
   */
 private static class ResultSetToTableRow implements JdbcIO.RowMapper<TableRow> {

   static SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
    static DateTimeFormatter datetimeFormatter =
        DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm:ss.SSSSSS");
    static SimpleDateFormat timestampFormatter =
        new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.SSSSSSXXX");

    @Override
    public TableRow mapRow(ResultSet resultSet) throws Exception {

      ResultSetMetaData metaData = resultSet.getMetaData();

      TableRow outputTableRow = new TableRow();

      for (int i = 1; i <= metaData.getColumnCount(); i++) {
        if (resultSet.getObject(i) == null) {
          outputTableRow.set(metaData.getColumnName(i), resultSet.getObject(i));
          continue;
        }

       /* 
         * DATE:      EPOCH MILLISECONDS -> yyyy-MM-dd
         * DATETIME:  EPOCH MILLISECONDS -> yyyy-MM-dd hh:mm:ss.SSSSSS
         * TIMESTAMP: EPOCH MILLISECONDS -> yyyy-MM-dd hh:mm:ss.SSSSSSXXX
         *
         * MySQL drivers have ColumnTypeName in all caps and postgres in small case
        */ 
        switch (metaData.getColumnTypeName(i).toLowerCase()) {
          case "date":
            outputTableRow.set(
                metaData.getColumnName(i), dateFormatter.format(resultSet.getDate(i)));
            break;
          case "datetime":
            outputTableRow.set(
                metaData.getColumnName(i),
                datetimeFormatter.format((TemporalAccessor) resultSet.getObject(i)));
            break;
          case "timestamp":
            outputTableRow.set(
                metaData.getColumnName(i), timestampFormatter.format(resultSet.getTimestamp(i)));
            break;
          case "clob":
            Clob clobObject = resultSet.getClob(i);
            if (clobObject.length() > Integer.MAX_VALUE) {
              LOG.warn(
                  "The Clob value size {} in column {} exceeds 2GB and will be truncated.",
                  clobObject.length(),
                  metaData.getColumnName(i));
            }
            outputTableRow.set(
                metaData.getColumnName(i), clobObject.getSubString(1, (int) clobObject.length()));
            break;
          default:
            outputTableRow.set(metaData.getColumnName(i), resultSet.getObject(i));
        }
      }

      return outputTableRow;
    }
  }
}

